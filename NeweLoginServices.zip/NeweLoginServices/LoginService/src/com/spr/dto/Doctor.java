package com.spr.dto;

public class Doctor {
	private int doctorId;
	private String speciality;
	private String availableTime;
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	public String getAvailableTime() {
		return availableTime;
	}
	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", speciality=" + speciality + ", availableTime=" + availableTime + "]";
	}
	public Doctor(int doctorId, String speciality, String availableTime) {
		super();
		this.doctorId = doctorId;
		this.speciality = speciality;
		this.availableTime = availableTime;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
