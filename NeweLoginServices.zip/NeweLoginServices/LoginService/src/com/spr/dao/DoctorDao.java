package com.spr.dao;

import java.util.List;

import com.spr.dto.Doctor;



public interface DoctorDao {

	public Boolean insert(Doctor doctor);
	public int update(Doctor doctor );
	
	public Boolean delete(int id);
	
	public List<Doctor> selectAllDoctor();
	public Doctor selectbyId(int doctorId);
}
