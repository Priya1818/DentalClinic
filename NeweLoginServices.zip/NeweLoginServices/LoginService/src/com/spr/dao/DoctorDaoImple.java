package com.spr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spr.dto.Doctor;
import com.spr.dto.User;



@Repository
public class DoctorDaoImple implements DoctorDao{

	@Autowired
	private JdbcTemplate jdbctemplate;


	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}

	public DoctorDaoImple() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	@Override
	public Boolean insert(Doctor doctor) {
		String	sql= "insert into doctor(doctorId,speciality,available_time) values(?,?,?)";





		int	b=jdbctemplate.update(sql, new Object [] {


				doctor.getDoctorId(),
				doctor.getSpeciality(),
				doctor.getAvailableTime(),
		
				
		});
		System.out.println(b+"inserted into doctor");

		return true;

	}

	@Override
	public int update(Doctor doctor) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Boolean delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Doctor selectbyId(int doctorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Doctor> selectAllDoctor() {
		System.out.println("Selecting...");
		String sql="select user.userId,  ";
		List<Doctor> doctorList=jdbctemplate.query(sql, new RowMapper<Doctor>() {

			@Override
			public Doctor mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Doctor doctor = new Doctor();
				doctor.setDoctorId(rs.getInt("doctorId"));
				doctor.setSpeciality(rs.getString("speciality"));
				doctor.setAvailableTime(rs.getString(""));
				
				return doctor;
			}
		});
		//System.out.println(u);
		//return userList;
		return doctorList;


	}
	
}