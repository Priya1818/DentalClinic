package com.spr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

import com.spr.dto.User;
import com.spr.service.UserServiceImple;
@Controller
public class UserController {
	
	@Autowired
	private UserServiceImple userService;
	

	public void setUserService(UserServiceImple userService) {
		this.userService = userService;
	}
	
	@RequestMapping(value = "UserList",method = RequestMethod.GET)
	public ModelAndView selectAllUser() {
		ModelAndView mv=new ModelAndView();
		List<User> user=userService.selectAllUser();
		System.out.println(user);
		mv.addObject("user", user);
		
		mv.setViewName("UserList");
		return mv;
		
	}
	
	
	@RequestMapping(value = "DoctorList",method = RequestMethod.GET)
	public ModelAndView selectAllDoctor() {
		ModelAndView mv=new ModelAndView();
		List<User> user=userService.selectAllDoctor();
		System.out.println(user);
		mv.addObject("user", user);
		
		mv.setViewName("HomepageAdmin");
		return mv;
		
	}
	
	
	
	
	
	
	
	@RequestMapping(value="/edit",method=RequestMethod.POST)
	public ModelAndView editUserForm(@RequestParam("userId") int UserId) {
	    ModelAndView mav = new ModelAndView("PatientUpdate");
	    User user = userService.selectbyId(UserId);
	    mav.addObject("User", user);
	    
	    mav.setViewName("PatientUpdate");
	    
	    System.out.println("�ditttt"+user);
	    return mav;
	}

	@RequestMapping(value="/regisp",method=RequestMethod.POST)
	public String insert(@ModelAttribute("user")User user,ModelMap model) {
		
		
		System.out.println("hey"+user);
		userService.insert(user);
		try {
			
			
			System.out.println("success");
			return "Index";
			
		}catch(Exception e){
			System.out.println("Fail");
			return "Register";
		}
	}
	
	
	@RequestMapping(value="/regisD",method=RequestMethod.POST)
	public String insertDoctor(@ModelAttribute("user")User user,ModelMap model) {
		
		
		System.out.println("hey"+user);
		userService.insertDoctor(user);
		try {
			
			
			System.out.println("success");
			return "Index";
			
		}catch(Exception e){
			System.out.println("Fail");
			return "Register";
		}
	}
	
	@RequestMapping(value ="/saveUser",method = RequestMethod.POST)
	public String update(@ModelAttribute("user")User user,ModelMap model)
	{System.out.println("updateeee");
		
		userService.update(user);
try {
			
			
			System.out.println("success");
			return "save";
			
		}catch(Exception e){
			System.out.println("Fail");
			return "Register";
		}
		
		
	}
	

	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String delete(@RequestParam("userId") int UserId) {
		
		
		
		userService.delete(UserId);
		try {
			
			
			System.out.println("success");
			return "HomepageAdmin";
			
		}catch(Exception e){
			System.out.println("Fail");
			return "Register";
		}
	}
	
	
}
