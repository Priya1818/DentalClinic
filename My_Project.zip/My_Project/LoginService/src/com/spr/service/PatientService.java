package com.spr.service;

import com.spr.dto.Patient;

public interface PatientService {
	public void insert(Patient patient);
}
