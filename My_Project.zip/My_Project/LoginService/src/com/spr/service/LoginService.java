package com.spr.service;

import com.spr.dto.Login;

public interface LoginService {
	 Login validateUser(Login login);
	
}
