package com.spr.dao;

import com.spr.dto.Patient;

public interface PatientDao {
	public Boolean insert(Patient patient);
}
